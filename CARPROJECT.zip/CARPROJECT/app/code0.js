gdjs.Untitled_32sceneCode = {};
gdjs.Untitled_32sceneCode.localVariables = [];
gdjs.Untitled_32sceneCode.idToCallbackMap = new Map();
gdjs.Untitled_32sceneCode.GDTop_9595RoadObjects1= [];
gdjs.Untitled_32sceneCode.GDTop_9595RoadObjects2= [];
gdjs.Untitled_32sceneCode.GDBot_9595RoadObjects1= [];
gdjs.Untitled_32sceneCode.GDBot_9595RoadObjects2= [];
gdjs.Untitled_32sceneCode.GDSky_9595BLueObjects1= [];
gdjs.Untitled_32sceneCode.GDSky_9595BLueObjects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite3Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite3Objects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite4Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite4Objects2= [];
gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1= [];
gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects2= [];
gdjs.Untitled_32sceneCode.GDDown_9595ButtonObjects1= [];
gdjs.Untitled_32sceneCode.GDDown_9595ButtonObjects2= [];
gdjs.Untitled_32sceneCode.GDUp_9595buttonObjects1= [];
gdjs.Untitled_32sceneCode.GDUp_9595buttonObjects2= [];
gdjs.Untitled_32sceneCode.GDPoliceObjects1= [];
gdjs.Untitled_32sceneCode.GDPoliceObjects2= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1= [];
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2= [];
gdjs.Untitled_32sceneCode.GDNewSprite5Objects1= [];
gdjs.Untitled_32sceneCode.GDNewSprite5Objects2= [];
gdjs.Untitled_32sceneCode.GDroadObjects1= [];
gdjs.Untitled_32sceneCode.GDroadObjects2= [];
gdjs.Untitled_32sceneCode.GDTimerObjects1= [];
gdjs.Untitled_32sceneCode.GDTimerObjects2= [];
gdjs.Untitled_32sceneCode.GDtimeObjects1= [];
gdjs.Untitled_32sceneCode.GDtimeObjects2= [];
gdjs.Untitled_32sceneCode.GDGasAMTObjects1= [];
gdjs.Untitled_32sceneCode.GDGasAMTObjects2= [];
gdjs.Untitled_32sceneCode.GDGasNumObjects1= [];
gdjs.Untitled_32sceneCode.GDGasNumObjects2= [];
gdjs.Untitled_32sceneCode.GDGreenDotBarObjects1= [];
gdjs.Untitled_32sceneCode.GDGreenDotBarObjects2= [];
gdjs.Untitled_32sceneCode.GDgas_9595stationObjects1= [];
gdjs.Untitled_32sceneCode.GDgas_9595stationObjects2= [];


gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer_95959595CarObjects1Objects = Hashtable.newFrom({"Player_Car": gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPoliceObjects1Objects = Hashtable.newFrom({"Police": gdjs.Untitled_32sceneCode.GDPoliceObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSprite5Objects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite5": gdjs.Untitled_32sceneCode.GDNewSprite5Objects1, "NewSprite": gdjs.Untitled_32sceneCode.GDNewSpriteObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPoliceObjects1Objects = Hashtable.newFrom({"Police": gdjs.Untitled_32sceneCode.GDPoliceObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSprite5Objects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects = Hashtable.newFrom({"NewSprite5": gdjs.Untitled_32sceneCode.GDNewSprite5Objects1, "NewSprite": gdjs.Untitled_32sceneCode.GDNewSpriteObjects1});
gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDgas_95959595stationObjects1Objects = Hashtable.newFrom({"gas_station": gdjs.Untitled_32sceneCode.GDgas_9595stationObjects1});
gdjs.Untitled_32sceneCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GasNum"), gdjs.Untitled_32sceneCode.GDGasNumObjects1);
gdjs.copyArray(runtimeScene.getObjects("GreenDotBar"), gdjs.Untitled_32sceneCode.GDGreenDotBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player_Car"), gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1);
gdjs.copyArray(runtimeScene.getObjects("time"), gdjs.Untitled_32sceneCode.GDtimeObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGasNumObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGasNumObjects1[i].getBehavior("Text").setText("Gas_");
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDtimeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDtimeObjects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(0).getAsString());
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[i].resetTimer("testing");
}
}
{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.Untitled_32sceneCode.GDGreenDotBarObjects1.length !== 0 ? gdjs.Untitled_32sceneCode.GDGreenDotBarObjects1[0] : null), (gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length !== 0 ? gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[0] : null));
}
}

}


{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Down_Button"), gdjs.Untitled_32sceneCode.GDDown_9595ButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite5"), gdjs.Untitled_32sceneCode.GDNewSprite5Objects1);
gdjs.copyArray(runtimeScene.getObjects("Player_Car"), gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Up_button"), gdjs.Untitled_32sceneCode.GDUp_9595buttonObjects1);
gdjs.copyArray(runtimeScene.getObjects("road"), gdjs.Untitled_32sceneCode.GDroadObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDroadObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDroadObjects1[i].setXOffset((( gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[0].getPointX("")) * 2);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSprite5Objects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSprite5Objects1[i].setX((( gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[0].getPointX("")) + 1500);
}
for(var i = 0, len = gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[i].setX((( gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[0].getPointX("")) + 1500);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[i].setZOrder((gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[i].getPointY("")));
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDUp_9595buttonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDUp_9595buttonObjects1[i].setX((( gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[0].getPointX("")) - 150);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDDown_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDDown_9595ButtonObjects1[i].setX((( gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[0].getPointX("")) - 150);
}
}
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player_Car"), gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[i].addForce(100, 0, 1);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Down_Button"), gdjs.Untitled_32sceneCode.GDDown_9595ButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDDown_9595ButtonObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDDown_9595ButtonObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDDown_9595ButtonObjects1[k] = gdjs.Untitled_32sceneCode.GDDown_9595ButtonObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDDown_9595ButtonObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player_Car"), gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Move", (gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[i].getPointY("")) + 20, "easeInOutQuad", 0.04, false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Up_button"), gdjs.Untitled_32sceneCode.GDUp_9595buttonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDUp_9595buttonObjects1.length;i<l;++i) {
    if ( gdjs.Untitled_32sceneCode.GDUp_9595buttonObjects1[i].getBehavior("ButtonFSM").IsPressed(null) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDUp_9595buttonObjects1[k] = gdjs.Untitled_32sceneCode.GDUp_9595buttonObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDUp_9595buttonObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player_Car"), gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[i].getBehavior("Tween").addObjectPositionYTween2("Move", (gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[i].getPointY("")) - 20, "easeInOutQuad", 0.04, false);
}
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player_Car"), gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Police"), gdjs.Untitled_32sceneCode.GDPoliceObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPlayer_95959595CarObjects1Objects, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPoliceObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "vine-boom-392646.mp3", false, 50, 1);
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("GreenDotBar"), gdjs.Untitled_32sceneCode.GDGreenDotBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player_Car"), gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "spawn");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "tests");
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[i].resetTimer("testing");
}
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "gasoline");
}
{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length !== 0 ? gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[0] : null), (gdjs.Untitled_32sceneCode.GDGreenDotBarObjects1.length !== 0 ? gdjs.Untitled_32sceneCode.GDGreenDotBarObjects1[0] : null));
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite5"), gdjs.Untitled_32sceneCode.GDNewSprite5Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "spawn") >= 3;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject(runtimeScene, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSprite5Objects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects);
}
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDNewSpriteObjects1 */
/* Reuse gdjs.Untitled_32sceneCode.GDNewSprite5Objects1 */
gdjs.Untitled_32sceneCode.GDPoliceObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDPoliceObjects1Objects, (( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length === 0 ) ? (( gdjs.Untitled_32sceneCode.GDNewSprite5Objects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDNewSprite5Objects1[0].getPointX("")) :gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0].getPointX("")), (( gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length === 0 ) ? (( gdjs.Untitled_32sceneCode.GDNewSprite5Objects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDNewSprite5Objects1[0].getPointY("")) :gdjs.Untitled_32sceneCode.GDNewSpriteObjects1[0].getPointY("")), "player");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "spawn");
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player_Car"), gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber((( gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[0].getPointX("")) / 100);
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "tests") >= 1;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("time"), gdjs.Untitled_32sceneCode.GDtimeObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(0).add(1);
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDtimeObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDtimeObjects1[i].getBehavior("Text").setText(runtimeScene.getScene().getVariables().getFromIndex(0).getAsString());
}
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "tests");
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("GreenDotBar"), gdjs.Untitled_32sceneCode.GDGreenDotBarObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player_Car"), gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1);
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDGreenDotBarObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDGreenDotBarObjects1[i].SetValue((( gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[0].getBehavior("Health").Health(null)), null);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player_Car"), gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length;i<l;++i) {
    if ( !(gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[i].getTimerElapsedTimeInSecondsOrNaN("testing") > 1) ) {
        isConditionTrue_0 = true;
        gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[k] = gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[i];
        ++k;
    }
}
gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1 */
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[i].getBehavior("Health").Hit(0.25, true, true, null);
}
}
{for(var i = 0, len = gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length ;i < len;++i) {
    gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[i].resetTimer("testing");
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("NewSprite"), gdjs.Untitled_32sceneCode.GDNewSpriteObjects1);
gdjs.copyArray(runtimeScene.getObjects("NewSprite5"), gdjs.Untitled_32sceneCode.GDNewSprite5Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "gasoline") >= 5;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject(runtimeScene, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDNewSprite5Objects1ObjectsGDgdjs_9546Untitled_959532sceneCode_9546GDNewSpriteObjects1Objects);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Player_Car"), gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1);
gdjs.Untitled_32sceneCode.GDgas_9595stationObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.Untitled_32sceneCode.mapOfGDgdjs_9546Untitled_959532sceneCode_9546GDgas_95959595stationObjects1Objects, (( gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length === 0 ) ? 0 :gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1[0].getPointX("")) - 200, 300, "");
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "gasoline");
}
}

}


};

gdjs.Untitled_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Untitled_32sceneCode.GDTop_9595RoadObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTop_9595RoadObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBot_9595RoadObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBot_9595RoadObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSky_9595BLueObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSky_9595BLueObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDown_9595ButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDown_9595ButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDUp_9595buttonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDUp_9595buttonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPoliceObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPoliceObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite5Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite5Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDroadObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDroadObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTimerObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTimerObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDtimeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDtimeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGasAMTObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGasAMTObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGasNumObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGasNumObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGreenDotBarObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGreenDotBarObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDgas_9595stationObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDgas_9595stationObjects2.length = 0;

gdjs.Untitled_32sceneCode.eventsList0(runtimeScene);
gdjs.Untitled_32sceneCode.GDTop_9595RoadObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTop_9595RoadObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDBot_9595RoadObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDBot_9595RoadObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDSky_9595BLueObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDSky_9595BLueObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite2Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite3Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite3Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite4Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite4Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPlayer_9595CarObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDDown_9595ButtonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDDown_9595ButtonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDUp_9595buttonObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDUp_9595buttonObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDPoliceObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDPoliceObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite5Objects1.length = 0;
gdjs.Untitled_32sceneCode.GDNewSprite5Objects2.length = 0;
gdjs.Untitled_32sceneCode.GDroadObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDroadObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDTimerObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDTimerObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDtimeObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDtimeObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGasAMTObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGasAMTObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGasNumObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGasNumObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDGreenDotBarObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDGreenDotBarObjects2.length = 0;
gdjs.Untitled_32sceneCode.GDgas_9595stationObjects1.length = 0;
gdjs.Untitled_32sceneCode.GDgas_9595stationObjects2.length = 0;


return;

}

gdjs['Untitled_32sceneCode'] = gdjs.Untitled_32sceneCode;
